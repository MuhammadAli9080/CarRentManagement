# Rent-a-Car-Management-System
It is a semester project for Object Oriented Programming written in java. (a mini Project)

Username: admin

Password: 123

For queries contact: iamabdullahshahid@gmail.com
